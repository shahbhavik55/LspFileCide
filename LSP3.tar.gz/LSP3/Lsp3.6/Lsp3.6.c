/*

6. Write a program which accept file name from user and read whole file.

*/


#include"header.h"


int main()
{
	int fd,bytes,ret;
	char fname[11],*buff = NULL;
	struct stat filestat;

	printf("File Name:-");
	scanf("%s",fname);

	fd = open(fname,O_RDONLY);
	
	if(fd == -1)
	{
		perror("Error");
		return errno;
	}

	ret = stat(fname,&filestat);
	
	if(ret < 0)
	{
		printf("Info. of file is not get");
		return -1;
	}

	buff = (char*)malloc(filestat.st_size);
	ret = read(fd,buff,filestat.st_size);

	printf("\n%s",buff);
}
