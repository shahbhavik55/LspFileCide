#include<stdio.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<errno.h>

