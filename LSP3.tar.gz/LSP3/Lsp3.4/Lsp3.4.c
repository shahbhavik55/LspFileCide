/*

4. Write a program which accept file name from user and print all
information about that file.

*/


#include"header.h"

int main()
{
	char fname[11];
	int ret;
	struct stat filestat;

	printf("\nFile Name:-");
	scanf("%s",fname);

	ret=stat(fname,&filestat);	

	if(ret < 0)
	{
		perror("Info. of file is not get");
		return errno;
	}

	printf("\nFile size:-%d",(int)filestat.st_size);
	printf("\nFile Inode No:-%d",(int)filestat.st_ino);
	printf("\nFile no. of links:-%d",(int)filestat.st_nlink);
	printf("\nFile blocks:-%d",(int)filestat.st_blocks);
	printf("\nFile system no:-%d",(int)filestat.st_dev);
	printf("\nFile permission:");

	printf(S_ISDIR(filestat.st_mode) ? "d" : "-");
	printf( (filestat.st_mode & S_IRUSR) ? "r" : "-");
	printf( (filestat.st_mode & S_IWUSR) ? "w" : "-");
	printf( (filestat.st_mode & S_IXUSR) ? "x" : "-");
	printf( (filestat.st_mode & S_IRGRP) ? "r" : "-");
	printf( (filestat.st_mode & S_IWGRP) ? "w" : "-");
	printf( (filestat.st_mode & S_IXGRP) ? "x" : "-");
	printf( (filestat.st_mode & S_IROTH) ? "r" : "-");
	printf( (filestat.st_mode & S_IWOTH) ? "w" : "-");
	printf( (filestat.st_mode & S_IXOTH) ? "x" : "-");
	
	if(S_ISLNK(filestat.st_mode))
		printf("\nIt's symbolic link");
	else
		printf("\nIt's not symbolic link");

}
