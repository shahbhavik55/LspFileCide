/*

3. Write a program which accept file name and on mode and that program
check whether our process can access that file in accepted mode or
not.

*/

#include"header.h"

int main()
{
	char fname[11],mode[11];
	int fd,modeint=0;

	printf("File Name:-");
	scanf("%s",fname);
	printf("Access Mode:-");
	scanf("%s",mode);

	if(strcmp(mode,"read") == 0)
	{
		modeint=R_OK;
	}	
	else if(strcmp(mode,"write") == 0)
	{	
		modeint=W_OK;
	}	
	else if(strcmp(mode,"execute") == 0)
	{	
		modeint=X_OK;
	}	
	else
	{
		printf("Wrong i/p");
		return(-1);
	}

	if(access(fname,modeint) < 0)
		printf("Our process can't have %s permision",mode);
	else
		printf("Our process have %s permision",mode);
}
