/*

10. Write a program which accept directory name from user and print
name of such a file having largest size.

*/


#include"header.h"

int main()
{
	DIR *dir;
	struct dirent *entry;
	struct stat filestat;
	char dname[11];
	int fd,maxsize=0;

	printf("Directory name:-");
	scanf("%s",dname);

	if( (dir = opendir(dname)) == NULL)
	{
		perror("Error");
		return errno;
	}	

	while( (entry = readdir(dir)) != NULL)
	{
		stat(entry->d_name,&filestat);

		if( (int)filestat.st_size > maxsize)
			maxsize=filestat.st_size;
	}
	
	dir=NULL;
	dir = opendir(dname);
	entry=NULL;

	while( (entry = readdir(dir)) != NULL)
	{
		stat(entry->d_name,&filestat);
		if( (filestat.st_size) == maxsize)
			printf("\n Inode No:-%d\t Name:-%20s\t size=%d",(int)entry->d_ino,entry->d_name,(int)filestat.st_size);
	}
	
	
	closedir(dir);
	return 0;
}
