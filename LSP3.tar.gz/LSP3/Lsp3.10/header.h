#include<stdio.h>
#include<dirent.h>
#include<sys/types.h>
#include<sys/stat.h>

#include<errno.h>

#include<fcntl.h>

