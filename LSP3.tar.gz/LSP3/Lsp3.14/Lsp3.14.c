/*

14. Write program which accept directory name from user and delete all
empty files from that directory.

*/

#include"header.h"

int main() 
{
	DIR *dir;
	struct dirent *entry;
	struct stat fileStat;	// Structure which stores all information of file.
	int max = 0;
	char dname[100];	

	printf("Directory name:-");
	scanf("%s",dname);
	
	if ((dir = opendir(dname)) == NULL)
	{
		perror("Unable to open specified directory\n");
		return errno;
	}

	while ((entry = readdir(dir)) != NULL)
	{
		stat(entry->d_name,&fileStat);				
		
		if(S_ISREG(fileStat.st_mode))
		{		
			if((int)fileStat.st_size == 0)
			{
				remove(entry->d_name);
			}
		}
		memset(&fileStat,0,sizeof(fileStat));
	}
	
	closedir(dir);
	return 0;
}
