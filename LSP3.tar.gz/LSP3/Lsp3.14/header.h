#include<sys/types.h>
#include<dirent.h>
#include<stdio.h>
#include<string.h>
#include<sys/stat.h>
#include<errno.h>
#include<fcntl.h>

