/*

12. Write a program which accept directory name and file name from
user and check whether that file is present in that directory or not.

*/

#include"header.h"

int main()
{
	DIR *dir;
	struct dirent *entry;
	char dname[110],fname[110];
	struct stat filestat;

	printf("Directory name:-");
	scanf("%s",dname);
	printf("File name:-");
	scanf("%s",fname);

	if((dir = opendir(dname)) == NULL)
	{
		perror("Error");
		return errno;
	}	

	while((entry = readdir(dir)) != NULL)
	{
		if( strcmp(fname,entry->d_name) == 0)		
		{
			printf("file is present in %s derictory.",dname);
			closedir(dir);
			return 0;
		
		}
	}

	printf("file is not present in %s derictory.",dname);
	closedir(dir);
	return 0;
}
