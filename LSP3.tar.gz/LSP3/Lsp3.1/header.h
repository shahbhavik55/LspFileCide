#include<stdio.h>
#include<fcntl.h>
#include<errno.h>

