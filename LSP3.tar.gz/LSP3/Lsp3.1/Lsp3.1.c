/*

1. Write a program which accept file name from user and open that file.

*/

#include"header.h"

int main()
{
	char fname[11];
	int fd;

	printf("File Name:-");
	scanf("%s",fname);

	fd=open(fname,1);

	if(fd == -1)
	{
		perror("Failed to open the file");
		return errno;
	}	

	close(fd);
	return 0;
}
