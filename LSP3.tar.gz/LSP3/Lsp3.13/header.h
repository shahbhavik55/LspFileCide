#include<stdio.h>
#include<dirent.h>
#include<errno.h>
#include<sys/types.h>
#include<string.h>

