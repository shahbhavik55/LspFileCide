/*

13. Write a program which accept two directory names from user and move all files from source directory to destination directory.

*/

#include"header.h"

int main()
{
	DIR *dir,*dir2;
	struct dirent *entry;
	char dname1[110],dname2[110],oldpath[128],newpath[128];

	printf("Source Directory name:-");
	scanf("%s",dname1);
	printf("Desination Directory name:-");
	scanf("%s",dname2);

	if((dir = opendir(dname1)) == NULL)
	{
		perror("Error1");
		return errno;
	}	
	if((dir2 = opendir(dname2)) == NULL)
	{
		printf("Error2");
		return errno;
	}	

	while((entry = readdir(dir)) != NULL)
	{
		sprintf(oldpath,"%s/%s",dname1,entry->d_name);
		sprintf(newpath,"%s/%s",dname2,entry->d_name);
		
		rename(oldpath,newpath);
		memset(&oldpath,0,sizeof(oldpath));
		memset(&newpath,0,sizeof(newpath));
	}

	closedir(dir);
	return 0;
}
