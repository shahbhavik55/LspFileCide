/*

2. Write a program which accept file name and mode from user and then
open that file in specified mode.

*/

#include"header.h"

int main()
{
	char fname[11],mode[11];
	int fd,modeint=0;

	printf("File Name:-");
	scanf("%s",fname);
	printf("Mode:-");
	scanf("%s",mode);

	if(strcmp(mode,"O_RDONLY") == 0)
	{
		modeint=0;
	}	
	else if(strcmp(mode,"O_WRONLY") == 0)
	{	
		modeint=1;
	}	
	else if(strcmp(mode,"O_RDWR") == 0)
	{	
		modeint=2;
	}	
	else
	{
		printf("Wrong i/p");
		return(-1);
	}

	fd=open(fname,modeint);

	if(fd>2)
		printf("File get open with fd-%d",fd);
	else
		printf("Error");
}
