#include <fcntl.h>
#include<stdio.h>
#include<sys/stat.h>
#include<errno.h>
#include<stdlib.h>

