/*

11. Write a program which accept two file names from user and copy the
contents of an existing file into newly created file.

*/

#include"header.h"


int main()
{
	int fd1,fd2,bytes,ret;
	char fname1[11],fname2[11],*buff = NULL;
	struct stat filestat;

	printf("Read File Name:-");
	scanf("%s",fname1);
	printf("Write File Name:-");
	scanf("%s",fname2);

	fd1 = open(fname1,O_RDONLY);
	fd2 = open(fname2,O_WRONLY);
	
	if(fd1 == -1)
	{
		perror("Error1");
		return errno;
	}

	if(fd2 == -1)
	{
		printf("Error2");
		return errno;
	}

	ret = stat(fname1,&filestat);
	
	buff = (char*)malloc(filestat.st_size);
	read(fd1,buff,filestat.st_size);	
	ret = write(fd2,buff,filestat.st_size);
	
	close(fd1);
	close(fd2);
	return 0;
}
