/*

9. Write a program which accept directory name from user and print all
file names and its types from that directory.

*/

#include"header.h"

int main()
{
	DIR *dir;
	struct dirent *entry;
	struct stat filestat;
	char dname[11];
	int fd;

	printf("Directory name:-");
	scanf("%s",dname);

	if( (dir = opendir(dname)) == NULL)
	{
		perror("Error");
		return errno;
	}	

	while( (entry = readdir(dir)) != NULL)
	{
		stat(entry->d_name,&filestat);

		printf("\n Inode No:-%d\t Name:-%20s\t type:-",(int)entry->d_ino,entry->d_name);

		if(S_ISREG(filestat.st_mode))
			printf("Regular File");
		else if(S_ISDIR(filestat.st_mode))
			printf("Directory");		
		else if(S_ISLNK(filestat.st_mode))
			printf("Symbolic Link");
	}

	closedir(dir);
	return 0;
}
