#include<fcntl.h>
#include<stdio.h>
#include<errno.h>

