/*

5. Write a program which accept file name and number of bytes from
user and read that number of bytes from file.

*/

#include"header.h"

int main()
{
	int fd,bytes,ret;
	char fname[11],buff[111];

	printf("File Name:-");
	scanf("%s",fname);
	printf("Bytes:-");
	scanf("%d",&bytes);

	fd = open(fname,O_RDONLY);
	
	if(fd == -1)
	{
		perror("Error");
		return errno;
	}

	ret = read(fd,buff,bytes);

	printf("\n%s",buff);
}
