/*

8. Write a program which accept directory name from user and print all
file names from that directory.

*/

#include"header.h"

int main()
{
	DIR *dir;
	struct dirent *entry;
	char dname[11];

	printf("Directory name:-");
	scanf("%s",dname);

	if((dir = opendir(dname)) == NULL)
	{
		perror("Error");
		return errno;
	}	

	while((entry = readdir(dir)) != NULL)
	{
		printf("\nInode No:-%d\tName:-%s",(int)entry->d_ino,entry->d_name);
	}

	closedir(dir);
	return 0;
}
