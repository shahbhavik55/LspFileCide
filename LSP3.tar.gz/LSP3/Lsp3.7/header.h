#include"stdio.h"
#include"fcntl.h"
#include"string.h"
#include<errno.h>
#include<stdlib.h>

