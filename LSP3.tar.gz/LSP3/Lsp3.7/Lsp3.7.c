/*

7. Write a program which accept file name from user and write string
in that file.

*/

#include"header.h"

int main()
{
	char fname[11],str[111];
	int fd,ret;

	printf("File Name:-");
	scanf("%s",fname);

	fd=open(fname,O_WRONLY);

	if(fd == -1)
	{
		perror("Error");
		return errno;
	}	

	printf("String:-\n");
	scanf("%[^\n]",str);
	
	ret=write(fd,str,strlen(str));
	
	if(ret != strlen(buff))
	{
		printf("Error: Unable to write whole contents\n");
	}

	close(fd);
	return 0;
}

